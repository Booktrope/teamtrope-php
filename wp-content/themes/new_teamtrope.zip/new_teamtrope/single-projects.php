<?php get_header() ?>
	<div id="content">
		<div class="padder">
		<?php do_action( 'bp_before_blog_page' ) ?>
		<div class="page" id="blog-page" role="main">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<h2 class="pagetitle">Book Project: <?php the_title(); ?></h2>
			<h4><strong>Status: </strong>
			<?php
			$this_id = get_the_ID();
			$terms_as_text = get_the_term_list( $this_id, 'status', '', ', ', '' ) ;
			echo $terms_as_text;
			?></h4>
			<h4><strong>Team Needs: </strong>
			<?php
			$terms_as_text = get_the_term_list( $this_id, 'needs', '', ', ', '' ) ;
			echo $terms_as_text;
			?></h4>
			<?php
			$terms_as_text = get_the_term_list( $this_id, 'status', '', ', ', '' ) ;
			$status_value = ( explode(',',strip_tags($terms_as_text) . ',EndOfList' ) ); 
			$custom_fields = get_post_custom( $this_id );
			if ( isset($custom_fields['proj_teamroom'][0]) && $custom_fields['proj_teamroom'][0] != "" ) {
				echo "<h4>Teamroom: <a href='" . $custom_fields['proj_teamroom'][0] . "'>Link to Teamroom</a></h4>\n\r";
			} else {
					echo "<h4>Teamroom Link: Not defined.</h4>\n\r";
			}
			?>
<?php //	$id = "12";
//gravity_form($id, $display_title=true, $display_description=true, $display_inactive=true, $field_values=null, $ajax=false); ?>
			<div class='gform_wrapper' id='gform_wrapper_1' >
				<div id='gf_progressbar_wrapper_7' class='gf_progressbar_wrapper'>
					<h3 class='gf_progressbar_title'>Overall Progress</h3>
					<div class='gf_progressbar'>
<?php					if ( in_array( "Manuscript (Pre-Edit)",$status_value ) ) { 
							$progress = '20%';
						} elseif ( in_array( "In-editing",$status_value ) ) {
							$progress = '40%';
						} elseif ( in_array( "In Proofreading",$status_value ) ) {
							$progress = '60%';
						} elseif ( in_array( "Pre-publication",$status_value ) ) {
							$progress = '85%';
						} elseif ( in_array( "Published",$status_value ) ) {
							$progress = '100%';
						}
						if ( $progress == "" ) { $progress = "5%"; } ?>
							<div class='gf_progressbar_percentage percentbar_blue percentbar_20' style='width:<?php echo $progress; ?>'><span><?php echo $progress; ?></span></div>
					</div> <!-- end of gf_progressbar -->
				</div> <!-- end of gf_progressbar_wrapper -->
			</div> <!-- end of gform_wrapper -->
			<div class="tabs">  <!-- top level tabs wrapper -->
				<ul>
					<li><a href="#tabs-1">Project Overview</a></li>
					<li><a href="#tabs-2">1. Team Formation</a></li>
					<li><a href="#tabs-3">2. Complete Manuscript</a></li>
					<li><a href="#tabs-4">3. Produce Book</a></li>
				</ul>
				<div id="tabs-1"> <!-- tabs-1 Proj Overview -->
					<br/>
					<h3 class="pagetitle">Title</a>: <?php the_title(); ?></h3>
					<h4><strong>Genre: </strong>
					<?php $terms_as_text = get_the_term_list( $this_id, 'genres', '', ', ', '' ); echo $terms_as_text;?></h4>
					<?php
					if ( isset($custom_fields['proj_author'][0]) ) {
						echo "<h3>Author: " . $custom_fields['proj_author'][0] . "</h3>\n\r";
					} 	else {
							echo "<h3>Author: N/A</h3>\n\r";
					}
					if ( isset($custom_fields['proj_book_manager'][0]) ) {
						echo "<h4>Book Manager: " . $custom_fields['proj_book_manager'][0] . "</h4>\n\r";
		 			} else {
							echo "<h4>Book Manager: N/A</h4>\n\r";
						}
					if ( isset($custom_fields['proj_editor'][0]) ) {
						echo "<h4>Editor: " . $custom_fields['proj_editor'][0] . "</h4>\n\r";
					} else {
						echo "<h4>Editor: N/A</h4>\n\r";
					}
					if ( isset($custom_fields['proj_cover_designer'][0]) ) {
						echo "<h4>Cover Designer: " . $custom_fields['proj_cover_designer'][0] . "</h4>\n\r";
					} else {
							echo "<h4>Cover Designer: N/A</h4>\n\r";
					}
					if ( isset($custom_fields['proj_proofreader'][0]) ) {
						echo "<h4>Proofreader: " . $custom_fields['proj_proofreader'][0] . "</h4>\n\r";
					} else {
							echo "<h4>Proofreader: N/A</h4>\n\r";
					}
					if ( isset($custom_fields['proj_isbn'][0]) ) {
						echo "<h4>ISBN Number: " . $custom_fields['proj_isbn'][0] . "</h4>\n\r";
					} else {
							echo "<h4>ISBN Number: </h4>\n\r";
					}
					?>
					<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
						<div class="entry">
							<strong>Description:</strong> <?php the_content( __( '<p class="serif">Read the rest of this page &rarr;</p>', 'buddypress' ) ); ?>
								<?php wp_link_pages( array( 'before' => '<div class="page-link"><p>' . __( 'Pages: ', 'buddypress' ), 'after' => '</p></div>', 'next_or_number' => 'number' ) ); ?>
						</div> <!-- end of entry -->
					</div> <!-- end of post_class -->
				</div> <!-- end of detail tabs-1 project overview -->
				<div id="tabs-2"> <!-- top level tabs-2 Team Formation -->
					<br/><br/>
					<div class="tabs"> <!-- tabs-2 detail wrapper -->
						<ul>
							<li><a href="#tabs-1">Project<br/>Interest</a></li>
							<li><a href="#tabs-2">1099<br/>Form</a></li>
							<li><a href="#tabs-3">Revenue<br/>Split</a></li>
						</ul>
						<div id="tabs-1"> <!-- detail project interest form -->
							<br/>
						<?php
						$terms_as_text = get_the_term_list( $this_id, 'needs', '', ', ', '' ) ;
						if ( strip_tags($terms_as_text) != '') {
                                                    $id = "1";
                                                    gravity_form($id, $display_title=true, $display_description=true, $display_inactive=true, $field_values=null, $ajax=false); 
                                                    //echo do_shortcode('[gravityform id="1" name="Project Interest" ajax="true"]'); 
						} else {
                                                    echo "<h3>Team is complete. Go Team Go!</h3>";
						}	?>
						</div> <!-- end of  Project Interest -->
						<div id="tabs-2"> <!-- 1099 Form -->
							<br/>
							<?php 	$id = "4";
									gravity_form($id, $display_title=true, $display_description=true, $display_inactive=true, $field_values=null, $ajax=false); ?>
							<?php// echo do_shortcode('[gravityform id="2" name="Submit Revenue" ajax="true"]'); ?>
						</div> <!-- end of 1099 -->
                                                <div id="tabs-3"> <!-- detail level tabs-3 Revenue Split -->
							<br/>
							<?php 	$id = "2";
									gravity_form($id, $display_title=true, $display_description=true, $display_inactive=true, $field_values=null, $ajax=false); ?>
							<?php// echo do_shortcode('[gravityform id="2" name="Submit Revenue" ajax="true"]'); ?>
						</div> <!-- end of tabs-3 Revenue Split -->
					</div> <!-- end of low level tabs under team formation -->
				</div> <!-- end of Team Formation (top tabs-1) -->
				<div id="tabs-3"> <!-- tabs-3 Complete Manuscript -->
					<br/>Finalize the manuscript and complete the editing, proofreading, layout and final approval.
					<div class="tabs"> <!-- wrapper for Complete Manuscript -->
						<ul>
							<li><a href="#tabs-1">Submit Edited<br/>Manuscript</a></li>
							<li><a href="#tabs-2">Submit Proofread<br/>Manuscript</a></li>
							<li><a href="#tabs-3">Upload<br/>Layout</a></li>
							<li><a href="#tabs-4">Approve<br/>Layout</a></li>
							<li><a href="#tabs-5">Upload<br/>Final Document</a></li>
							<li><a href="#tabs-6">Approve <br/>Final Document</a></li>
						</ul>
						<div id="tabs-1"> <!-- tabs-1 Edited Manuscript -->
							<br/>
							<?php
							$terms_as_text = get_the_term_list( $this_id, 'status', '', ', ', '' ) ;
							echo do_shortcode('[gravityform id="8" name="1. Edited Manuscript" ajax="true"]'); 

							echo do_shortcode('[directory form="1" lightboxsettings="images" sort="4" dir="ASC" field_1.3="814"]'); 
							?>
						</div> <!-- end of tabs-1 Edited Manuscript -->
						<div id="tabs-2"> <!-- Proof Manuscript -->
							<br/>
							<?php
							$terms_as_text = get_the_term_list( $this_id, 'status', '', ', ', '' ) ;
							echo do_shortcode('[gravityform id="16" name="2. Proofread Manuscript" ajax="true"]'); 
							?>
						</div> <!-- end of Proofed Manuscript -->
						<div id="tabs-3"> <!-- Upload Layout  -->
							<br/>
							<?php
							$terms_as_text = get_the_term_list( $this_id, 'status', '', ', ', '' ) ;
							echo do_shortcode('[gravityform id="14" name="Upload Layout" ajax="true"]'); 
							?>
                                                        <?php
                                                        echo do_shortcode('[directory form="10" lightboxsettings="images" sort="4" dir="ASC" field_1.3="814"]'); 
                                                        ?>

						</div> <!-- end of Upload Layout -->
						<div id="tabs-4"> <!-- Approve Layout  -->
							<br/>
							<?php
							$terms_as_text = get_the_term_list( $this_id, 'status', '', ', ', '' ) ;
							echo do_shortcode('[gravityform id="10" name="Approve Layout" ajax="true"]'); 
							?>
                                                        <?php
                                                        echo do_shortcode('[directory form="14" lightboxsettings="images" sort="4" dir="ASC" field_1.3="814"]'); 
                                                        ?>
						</div> <!-- end of Approve Layout -->
						<div id="tabs-5">
							<br/>
							<?php
							$terms_as_text = get_the_term_list( $this_id, 'status', '', ', ', '' ) ;
							echo do_shortcode('[gravityform id="15" name="Upload Final Document" ajax="true"]'); 
							?>
                                                        <?php
                                                        echo do_shortcode('[directory form="9" lightboxsettings="images" sort="4" dir="ASC" field_1.3="814"]'); 
                                                        ?>

						</div> <!-- end of tabs-4 Print Document -->
                                                <div id="tabs-6">
							<br/>
                                                        <a href="http://teamtrope.com/wp-content/uploads/2012/08/Author-Review-Checklist_Laid-Out-Manuscript.xlsx">Author Review Checklist</a>
                                                        <br/>
                                                        <a href="http://teamtrope.com/wp-content/uploads/2012/08/Book-Production-Review-Checklist-v-1.2_BM.xlsx">Book Manager Review Checklist</a>
                                                        <br/>
                                                        <a href="http://teamtrope.com/wp-content/uploads/2012/08/Book-Production-Review-Checklist-v-1.2_BM.xlsx">Change Request Form</a>
                                                        <br/>
							<?php
							$terms_as_text = get_the_term_list( $this_id, 'status', '', ', ', '' ) ;
							echo do_shortcode('[gravityform id="9" name="Approve Final Document for Print" ajax="true"]'); 
							?>
                                                        <?php
                                                        echo do_shortcode('[directory form="15" lightboxsettings="images" sort="4" dir="ASC" field_1.3="814"]'); 
                                                        ?>
                                                        <br/>
                                                        

						</div> <!-- end of tabs-4 Print Document -->
                                        </div> <!-- end of wrapper for Complete Manuscript -->
				</div> <!-- end of tabs-2 top level Complete Manuscript -->
				<div id="tabs-4"> <!-- Produce book -->
					<br/>
					<div class="tabs"> <!-- wrapper for Produce Book -->
						<ul>
							<li><a href="#tabs-1">Upload Final Cover Art</a></li>
							<li><a href="#tabs-2">Publication Fact Sheet</a></li>
							<li><a href="#tabs-3">Upload eBook Files</a></li>
							<li><a href="#tabs-4">Final Review and Sign-off</a></li>
						</ul>
						<div id="tabs-1">
							<br/>
							<?php echo do_shortcode('[gravityform id="18" name="Upload Cover Art" ajax="true"]'); ?>
						</div>
						<div id="tabs-2">
							<br/>
							<?php
							echo do_shortcode('[gravityform id="7" name="Fact Sheet" ajax="true"]'); 
							?>
						</div> <!-- end of fact sheet -->
						<div id="tabs-3">
							<br/>
							<?php
							echo do_shortcode('[gravityform id="20" name="Upload ePubs" ajax="true"]'); 
							?>
                                                        <?php
                                                        echo do_shortcode('[directory form="21" lightboxsettings="images" sort="4" dir="ASC" field_1.3="814"]'); 
                                                        ?>

						</div> <!-- end of upload epubs -->
						<div id="tabs-4">
							<br/>
							<?php
							echo do_shortcode('[gravityform id="21" name="eBook Final Review" ajax="true"]'); 
							?>
                                                        <?php
                                                        echo do_shortcode('[directory form="20" lightboxsettings="images" sort="4" dir="ASC" field_1.3="814"]'); 
                                                        ?>
						</div>
					</div>  <!-- end of wrapper for Produce Book -->
				</div>  <!-- end of top level tabs-4 Produce book -->
			</div>  <!-- end of top level wrapper -->
			<?php edit_post_link( __( 'Edit this page.', 'buddypress' ), '<p class="edit-link">', '</p>'); ?>

			<?php // comments_template(); ?>

			<?php endwhile; endif; ?>

		</div><!-- .page -->

		<?php do_action( 'bp_after_blog_page' ) ?>

		</div><!-- .padder -->
	</div><!-- #content -->

	<?php get_sidebar() ?>

<?php get_footer(); ?>
