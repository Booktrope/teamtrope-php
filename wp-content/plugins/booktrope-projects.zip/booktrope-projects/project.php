<?php
/*
Plugin Name: BookTrope - Team Projects
Plugin URI: http://booktrope.com
Description: Custom Post Type Plugin to manage projects
Version: 1.0
Author: booktrope.com
Author URI: http://booktrope.com/
*/

function custom_meta_box_projects() {
    add_meta_box("project-details", "Project Details", "tt_cpt_project_details", "projects", "normal", "high");
}

add_action('admin_menu', 'custom_meta_box_projects');

function tt_cpt_project_details() {
    global $post;
	$custom = get_post_custom($post->ID);

	echo '<label for="proj_author">Author(s):</label><br />';
	echo '<input style="width: 85%;" type="text" name="proj_author" value="'.get_post_meta($post->ID, 'proj_author', true).'" /><br /><br />';		

	echo '<label for="proj_book_manager">Book Manager:</label><br />';
	echo '<input style="width: 85%;" type="text" name="proj_book_manager" value="'.get_post_meta($post->ID, 'proj_book_manager', true).'" /><br /><br />';	

	echo '<label for="proj_editor">Editor:</label><br />';
	echo '<input style="width: 85%;" type="text" name="proj_editor" value="'.get_post_meta($post->ID, 'proj_editor', true).'" /><br /><br />';
	
	echo '<label for="proj_cover_designer">Cover Designer:</label><br />';
	echo '<input style="width: 85%;" type="text" name="proj_cover_designer" value="'.get_post_meta($post->ID, 'proj_cover_designer', true).'" /><br /><br />';
}

/* When the project is saved, saves our custom project data */
function save_project_postdata() {
	global $post;
	update_post_meta($post->ID, "proj_author", $_POST["proj_author"]);
	update_post_meta($post->ID, "proj_book_manager", $_POST["proj_book_manager"]);
	update_post_meta($post->ID, "proj_editor", $_POST["proj_editor"]);
	update_post_meta($post->ID, "proj_cover_designer", $_POST["proj_cover_designer"]);
}

add_action('save_post', 'save_project_postdata', 1, 2); // save the custom fields



// Hook into WordPress
// add_action( 'admin_init', 'add_custom_metabox' );
add_action( 'save_post', 'save_custom_url' );

/**
 * Add meta box
 */
function add_custom_metabox() {
	add_meta_box( 'custom-metabox', __( 'URL &amp; Description' ), 'url_custom_metabox', 'projects', 'side', 'high' );
}

/**
 * Display the metabox
 */
function url_custom_metabox() {
	global $post;
	$urllink = get_post_meta( $post->ID, 'urllink', true );
	$urldesc = get_post_meta( $post->ID, 'urldesc', true );

	if ( !preg_match( "/http(s?):\/\//", $urllink )) {
		$errors = 'Url not valid';
		$urllink = 'http://';
	} 

	// output invlid url message and add the http:// to the input field
	if( $errors ) { echo $errors; } ?>

	<p><label for="siteurl">Url:<br />
		<input id="siteurl" size="37" name="siteurl" value="<?php if( $urllink ) { echo $urllink; } ?>" /></label></p>
	<p><label for="urldesc">Description:<br />
		<textarea id="urldesc" name="urldesc" cols="45" rows="4"><?php if( $urldesc ) { echo $urldesc; } ?></textarea></label></p>
<?php
}

/**
 * Process the custom metabox fields
 */
function save_custom_url( $post_id ) {
	global $post;	

	if( $_POST ) {
		update_post_meta( $post->ID, 'urllink', $_POST['siteurl'] );
		update_post_meta( $post->ID, 'urldesc', $_POST['urldesc'] );
	}
}

/**
 * Get and return the values for the URL and description
 */
function get_url_desc_box() {
	global $post;
	$urllink = get_post_meta( $post->ID, 'urllink', true );
	$urldesc = get_post_meta( $post->ID, 'urldesc', true );

	return array( $urllink, $urldesc );
}
?>